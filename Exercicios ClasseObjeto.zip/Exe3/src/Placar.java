public class Placar {
    public String nomeCasa, nomeVisitante;
    public int pontosCasa, pontosVisitante, periodoQuarto;

    // construtor
    public Placar(String nomeCasa, String nomeVisitante){
        this.nomeCasa = nomeCasa;
        this.nomeVisitante = nomeVisitante;
        this.pontosCasa = 0;
        this.pontosVisitante = 0;
        this.periodoQuarto = 1;
    }

    public void registrarPonto(int time, int tipo){
        if(time == 1){
            pontosCasa += tipo;
        }
        else if(time == 2){
            pontosVisitante += tipo;
        }
        else{
            System.out.println("Time inválido.");
        }
    }
    public void proximoQuarto(){

        if(periodoQuarto < 4){
            periodoQuarto++;
        }
        else{
            System.out.println("O jogo já terminou.");
        }

    }

    public String toString(){
            return "Casa: " + this.nomeCasa + " X Visitante: " + this.nomeVisitante +
            "\nPontos Casa: " + this.pontosCasa + "\nX  Pontos Visitante: " + this.pontosVisitante +
     "\nPeríodo: " + this.periodoQuarto;
}
}