public class TestaPlacar {
    public static void main(String args[]){
        //cria uma instancia da classe Placar cria um objeto
        Placar obj1 = new Placar("Franca","Corinthians");
        //exibe os dados
        obj1.registrarPonto(1, 20);
        System.out.println(obj1.toString());
        obj1.registrarPonto(2, 10);
        obj1.registrarPonto(1, 22);
        obj1.proximoQuarto();
        obj1.registrarPonto(2, 42);

        System.out.println(obj1.toString());
}
}

