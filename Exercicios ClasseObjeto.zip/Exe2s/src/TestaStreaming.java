public class TestaStreaming {
    public static void main(String args[]){
        //cria uma instancia da classe Streaming cria um objeto
        Streaming obj1 = new Streaming("Lucas","Básico");
        //exibe os dados
        obj1.assistirFilme("Branquelas");
        System.out.println(obj1.toString());
        obj1.cancelarAssinatura();
        System.out.println(obj1.toString());

        Streaming obj2 = new Streaming("Isadora","Família");

        //exibe os dados
        System.out.println(obj2.toString());
        obj2.assistirFilme("Como eu era antes de voce");
        System.out.println(obj2.toString());
        obj2.assistirFilme("Salve Rosa");
        System.out.println(obj2.toString());

    }

}
