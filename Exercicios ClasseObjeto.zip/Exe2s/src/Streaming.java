public class Streaming {
    public String usuario, plano;
    public float mensalidade;
    public boolean ativo;
    public String ultimoFilmeAssistido;


    // construtor
    public Streaming(String usuario, String plano) {
        this.usuario = usuario;
        this.plano = plano;
        switch (plano) {
            case "Básico":
                mensalidade = 25.90f;
                break;
            case "Premium":
                mensalidade = 45.90f;
                break;
            case "Família":
                mensalidade = 60.90f;
                break;
        }

        ativo = true;
        ultimoFilmeAssistido = "";
    }
    public void assistirFilme (String nomefilme){
        if (this.ativo){
            this.ultimoFilmeAssistido  = nomefilme;
            System.out.println("Assistindo:" + nomefilme);
        }
        else System.out.println("É necessário pagar a fatura.");
    }

    public void cancelarAssinatura(){
        if (this.ativo)
            this.ativo = false;
    }
    public String toString() {
        return "Usuário: " + this.usuario +
                "\nPlano: " + this.plano +
                "\nMensalidade: " + this.mensalidade +
                "\nStatus: " + (this.ativo ? "Ativo" : "Suspenso") +
                "\nUltimo filme assistido: " + this.ultimoFilmeAssistido;
    }
}
