public class Conta {
    public int numConta, agencia;
    public String nomeCliente;
    public float saldo;
    public boolean status;

    //construtor
    public Conta(int numConta,int agencia, String nomeCliente) {

        this.numConta = numConta;
        this.agencia = agencia;
        this.nomeCliente = nomeCliente;
        this.saldo = 0;
        this.status = true;
    }
    public void depositar(float x){
        if (this.status){
            this.saldo = saldo + x ;
            System.out.println("Depósito de :" + x + "realizado. Valor final de:" + this.saldo);
        }
        else System.out.println("Não foi possível realizar o depósito");
    }

    public void sacar(float y){
        if (this.status && this.saldo  >= y ){
            this.saldo -= y;
            System.out.println("Saque realizado com sucesso.Valor final de:" + this.saldo);
        }
        else System.out.println("Saldo insuficiente ou conta inativa");
    }

    public void encerrarConta(){
        if (this.saldo == 0 ){
            this.status = false;
            System.out.println("Conta encerrada com sucesso");
        }
        else
            System.out.println("É necessário que zere o valor da conta antes de encerra-lá. O saldo atual é de:" + this.saldo);
    }
    public String toString() {
        return "Número da conta: " + this.numConta + "\nAgencia: " + this.agencia + "\nCliente: " + this.nomeCliente + "\nSaldo atual: " + this.saldo + "\nStatus = " + (this.status);
    }
}

