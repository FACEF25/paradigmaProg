public class TestaConta {
    public static void main(String args[]){
        //cria uma instancia da classe Conta cria um objeto
        Conta obj1 = new Conta(1234,01, "João Silva");

        //exibe os dados
        obj1.depositar(500);
        obj1.sacar(200);
        System.out.println(obj1.toString());
        obj1.encerrarConta();
        obj1.sacar(300);
        System.out.println(obj1.toString());
        obj1.encerrarConta();
        System.out.println(obj1.toString());

        Conta obj2 = new Conta (4321,02,"Maria Souza");

        //exibe os dados
        obj2.sacar(50);
        System.out.println(obj2.toString());

    }

}
